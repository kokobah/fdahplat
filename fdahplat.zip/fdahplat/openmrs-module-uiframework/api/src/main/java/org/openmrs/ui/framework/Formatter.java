package org.openmrs.ui.framework;

import java.util.Locale;

public interface Formatter {
	
	public String format(Object o, Locale locale);
	
}
