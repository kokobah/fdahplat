package org.openmrs.ui.framework.page;

public interface PageViewProvider {
	
	PageView getView(String name);
	
}
