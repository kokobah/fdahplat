package org.openmrs.ui.framework.page;

public interface PageControllerProvider {
	
	public Object getController(String id);
	
}
