package org.openmrs.ui.framework.page;

public class PageAction extends Exception {
	
	private static final long serialVersionUID = 1L;
	
}
