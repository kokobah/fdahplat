package org.openmrs.ui.framework.fragment.action;

/**
 * Marker interface for all fragment action results
 */
public interface FragmentActionResult {
	
}
