package org.openmrs.ui.framework.fragment;

public interface FragmentViewProvider {
	
	FragmentView getView(String name);
	
}
