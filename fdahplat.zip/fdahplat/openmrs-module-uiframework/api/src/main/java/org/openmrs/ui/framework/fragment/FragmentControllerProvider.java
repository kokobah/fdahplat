package org.openmrs.ui.framework.fragment;

public interface FragmentControllerProvider {
	
	public Object getController(String id);
	
}
