package org.openmrs.ui.framework;

public interface Messager {
	
	public String message(String code, Object... args);
	
}
