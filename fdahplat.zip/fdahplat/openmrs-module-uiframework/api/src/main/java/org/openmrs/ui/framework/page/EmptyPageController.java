package org.openmrs.ui.framework.page;

/**
 * A Page controller that does nothing
 */
public class EmptyPageController {
	
	public void controller() {
	}
	
}
