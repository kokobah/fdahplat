[![Build Status](https://travis-ci.org/openmrs/openmrs-module-appui.svg?branch=master)](https://travis-ci.org/openmrs/openmrs-module-appui)

openmrs-module-appui
==========================

Support for using the App Framework's context in the UI Framework