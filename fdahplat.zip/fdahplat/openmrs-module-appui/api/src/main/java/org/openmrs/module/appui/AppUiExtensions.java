package org.openmrs.module.appui;

/**
 *
 */
public class AppUiExtensions {

    public static final String HEADER_CONFIG_EXTENSION = "org.openmrs.module.appui.header.config";

    public static final String HEADER_USER_ACCOUNT_MENU_ITEMS_EXTENSION = "org.openmrs.module.appui.header.userAccount.menuItems";

}
