package org.openmrs.module.appui;

import org.junit.Assert;
import org.junit.Test;

/**
 *
 */
public class AppUiActivatorTest {

    @Test
    public void test() {
        Assert.assertTrue(true);
    }

}
